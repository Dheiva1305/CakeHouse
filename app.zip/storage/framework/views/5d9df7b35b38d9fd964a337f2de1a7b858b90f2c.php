

<?php $__env->startSection('content'); ?>

    <div class="col-lg-12">
        <?php if($status = session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <strong><?php echo e($status); ?></strong>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="card">
                <div class="card-header d-flex align-items-center">
                    <h3>Gallery List</h3>
                    <div class="mx-auto">
                        <a href="<?php echo e(route('admin.home_slider.create')); ?>"><button class="btn btn-primary btn-sm mx-auto">Add Gallery</button></a>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table " id="myTable">
                        <thead>
                            <th>#</th>
                            <th>Image</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                            <?php
                                $i=1;
                            ?>
                            <?php $__currentLoopData = $home_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td>
                                        <?php if($data->image): ?>
                                            <img src="<?php echo e(asset('assets/media/images')); ?>/<?php echo e($data->image); ?>" alt="Image" width="80px">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a class="mx-2" href="<?php echo e(route('admin.home_slider.edit',$data->id)); ?>"><i class="fas fa-edit"></i></a>
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#myModalDelete<?php echo e($data->id); ?>">
                                            <i class="fas fa-trash text-danger"></i>
                                        </a>
                                    </td>
                                </tr>
                                <div class="modal" id="myModalDelete<?php echo e($data->id); ?>" data-bs-backdrop="static">
                                    <div class="modal-dialog modal-md modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Confirm Deletion</h4>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Are you sure you want to delete?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <form action="<?php echo e(route('admin.home_slider.delete', $data->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>

                                                    <input type="hidden" value="<?php echo e($data->id); ?>" name="id">
                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
        var table = $('#myTable').DataTable({
            buttons: [
                'csv'
            ]
        });
    });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cakehouse\resources\views/backend/home-slider/index.blade.php ENDPATH**/ ?>