

<?php $__env->startSection('content'); ?>

    <div class="col-lg-12">
        <div class="row">
            <div class="card">
                <div class="card-header d-flex align-items-center">
                    <h3>Update Service</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.service.update', $service->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="name">Category</label>
                           <select name="category" id="category" class="form-control">
                            <option value="">select category</option>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->slug); ?>"><?php echo e($data->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="name">Service Name</label>
                            <input type="text" class="form-control" name="name" id="name" value="<?php echo e($service->name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="name">Service Image</label>
                            <input type="file" class="form-control mb-2" name="image" id="image">
                            <img src="<?php echo e(asset('assets/media/images')); ?>/<?php echo e($service->image); ?>" alt="Image" width="50px">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-sm">Update</button>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cakehouse\resources\views/backend/services/edit.blade.php ENDPATH**/ ?>