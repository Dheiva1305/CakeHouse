

<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content'); ?>

    <section class="about-us">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-6 col-12 margin-bottom margin-top">
                    <div class="card">
                        <!-- <img src="<?php echo e(asset('frontend/images/ca2.jpg')); ?>" alt="Image" class="image-style"> -->
                        <img src="<?php echo e(asset('assets/media/images')); ?>/<?php echo e($data->image); ?>" alt="Image" class="image-style">
                        <h4 class="d-flex align-items-center justify-content-center p-3 truncate-service"><?php echo e($data->name); ?></h4>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- <div class="col-lg-4 col-md-4 col-sm-6 col-12 margin-bottom">
                    <div class="card">
                        <img src="<?php echo e(asset('frontend/images/ca3.jpg')); ?>" alt="Image"  class="image-style">
                        <h4 class="d-flex align-items-center justify-content-center p-3 truncate-service">Donuts</h4>
                    </div>                   
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-12 margin-bottom">
                    <div class="card">
                        <img src="<?php echo e('frontend/images/ca4.jpg'); ?>" alt="Image"  class="image-style">
                        <h4 class="d-flex align-items-center justify-content-center p-3 truncate-service">Small Cakes</h4>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-12 margin-bottom margin-top">
                    <div class="card">
                        <img src="<?php echo e('frontend/images/ca6.jpg'); ?>" alt="Image"  class="image-style">
                        <h4 class="d-flex align-items-center justify-content-center p-3 truncate-service">Macarons</h4>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-12 margin-bottom margin-top">
                    <div class="card">
                        <img src="<?php echo e('frontend/images/ca8.jpg'); ?>" alt="Image"  class="image-style">
                        <h4 class="d-flex align-items-center justify-content-center p-3 truncate-service"> Bithday Cakes</h4>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-12 margin-bottom margin-top ">
                    <div class="card">
                        <img src="<?php echo e('frontend/images/ca7.jpg'); ?>" alt="Image"  class="image-style">
                        <h4 class="d-flex align-items-center justify-content-center p-3 truncate-service">Fresh Cakes</h4>
                    </div>
                </div> -->

                <div class="col-md-12 mt-4 d-flex justify-content-center">
                    <?php echo $category->links(); ?>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cakehouse\resources\views/frontend/service.blade.php ENDPATH**/ ?>