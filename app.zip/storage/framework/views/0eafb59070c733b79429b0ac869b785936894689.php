

<?php $__env->startSection('title', 'Gallery'); ?>

<?php $__env->startSection('content'); ?>

    <section class="my-5">
        <div class="container">
            <div class="row">

            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12 margin-bottom margin-top">
                    <img src="<?php echo e(asset('assets/media/images')); ?>/<?php echo e($data->image); ?>" alt="Image" class="image-styles">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- <div class="col-lg-4 col-md-6 col-sm-6 col-12 margin-bottom">
                    <div class="card">
                        <img src="<?php echo e(asset('frontend/images/ca3.jpg')); ?>" alt="Image"  class="image-styles">
                    </div>                   
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12 margin-bottom">
                    <div class="card">
                        <img src="<?php echo e('frontend/images/ca4.jpg'); ?>" alt="Image"  class="image-styles">
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6 col-12 margin-bottom margin-top">
                    <div class="card">
                        <img src="<?php echo e(asset('frontend/images/cake.jpg')); ?>" alt="Image" class="image-styles">
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12 margin-bottom margin-top">
                    <div class="card">
                        <img src="<?php echo e(asset('frontend/images/ca5.jpg')); ?>" alt="Image"  class="image-styles">
                    </div>                   
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12 margin-bottom margin-top">
                    <div class="card">
                        <img src="<?php echo e('frontend/images/ca2.jpg'); ?>" alt="Image"  class="image-styles">
                    </div>
                </div> -->
                <div class="col-md-12 mt-4 d-flex justify-content-center">
                    <?php echo $gallery->links(); ?>

                </div>
            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cakehouse\resources\views/frontend/gallery.blade.php ENDPATH**/ ?>