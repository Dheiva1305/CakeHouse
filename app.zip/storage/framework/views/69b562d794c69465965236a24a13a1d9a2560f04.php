

<?php $__env->startSection('content'); ?>

    <div class="col-lg-12">
        <div class="row">
            <div class="card">
                <div class="card-header d-flex align-items-center">
                    <h3>Update Home Slids</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.home_slider.update', $home_slider->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="image">Image</label>
                            <input type="file" class="form-control mb-2" name="image" id="image">
                            <img src="<?php echo e(asset('assets/media/images')); ?>/<?php echo e($home_slider->image); ?>" alt="Image" width="50px">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-sm">Update</button>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cakehouse\resources\views/backend/home-slider/edit.blade.php ENDPATH**/ ?>