

<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('content'); ?>

    <?php 
        $about_title = App\Models\Setting::where('type','home_about_us_title')->first(); 
        $about_us_text = App\Models\Setting::where('type','about_us_text')->first(); 
        $mission_vission = App\Models\Setting::where('type','mission_vission')->first(); 
        $mission_vission_title = App\Models\Setting::where('type','mission_vission_title')->first(); 
    ?>

    <section class="about-us">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-6">
                    <div class="about-image d-flex align-items-center justify-content-center">
                        <img src="<?php echo e(asset('frontend/images/welcome-right.jpg')); ?>" alt="Image" class="image-style">
                    </div>
                </div>
                <div class="col-xl-6 offset-xl-1 col-lg-6 col-md-6 d-flex align-items-center">
                    <div class="about-content">
                        <div class="content">
                            <div class="about-line mb-3">
                                <h4><?php echo e(!empty($about_title) ? $about_title->value : ''); ?></h4>
                            </div>
                            <p class="about_para"><?php echo e(!empty($about_us_text) ? $about_us_text->value : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-6 col-md-6 margin-top d-flex align-items-center">
                    <div class="about-content">
                        <div class="content ">
                            <div class="about-line mb-3">
                                <h4><?php echo e(!empty($mission_vission_title) ? $mission_vission_title->value : ''); ?></h4>
                            </div>
                            <p class="about_para"><?php echo e(!empty($mission_vission) ? $mission_vission->value : ''); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-5 offset-xl-1 col-lg-5 col-md-6 d-flex align-items-center justify-content-center">
                    <div class="about-image">
                        <img src="<?php echo e(asset('frontend/images/ca2.jpg')); ?>" alt="Image" class="image-style">
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cakehouse\resources\views/frontend/about.blade.php ENDPATH**/ ?>